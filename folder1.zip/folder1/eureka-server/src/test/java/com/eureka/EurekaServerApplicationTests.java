package com.eureka;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EurekaServerApplicationTests {

	@Test
	public void contextLoads() {
	}
	public EurekaServerApplicationTests()
	{
		
	}
	
}





